chrome.management.getAll(function(items){
	var arr = [];
console.log(items);
	for (var i = 0; i < items.length; i++) {
		if(items[i].enabled == true && 
		items[i].installType == 'development' && 
		items[i].name != 'Extension Viewer ALPHA'){
			var str = items[i].id;
			reloadExtension(items[i].id);
			console.log('refreshed ' + items[i].name);
		}
	}
});

chrome.management.getAll(function(items) {
	var arr = [];
	for (var i = 0; i < items.length; i++) {
		arr.push(items[i].name + '::' + items[i].version + '::' + items[i].enabled + '::' + items[i].installType + '::' + items[i].id + '::' + items[i].homepageUrl);
	}
	arr.sort(
		function (a, b) {
			return a.toLowerCase().localeCompare(b.toLowerCase());
		}
	);
	for(i = 0; i < arr.length; ++i){
		createRow(arr[i]);
	}
});

$('#defaultEV').click(function(e) {
	chrome.tabs.update({
		url: 'chrome://extensions/'
	});
});
$('#moreFromDev').click(function(e) {
	chrome.tabs.update({
		url: 'appsFromDeveloper/appsFromDeveloper.html'
	});
});

function reloadExtension(id) {
    chrome.management.setEnabled(
		id, false, function() {
			chrome.management.setEnabled(id, true);

		}
	);
}

function createDetail(tr, value, i, id){
	var td = document.createElement('td');
	if(i == 2){
		tr.appendChild(td);
		var input = document.createElement('input');
		input.type = 'checkbox';
		if(value == 'true'){
			input.checked = true;
		}
		$(input).change(
			function(){
				var boo = false;
				if($(this).is(':checked')) boo = true;
				chrome.management.setEnabled(id, boo)
			}
		);
		td.appendChild(input);
	}else{
		td.innerText = value;
		if(value != 'normal') tr.appendChild(td);
	}
}

function createRow(obj){
	var $tbl = $('#body');
	var tr = document.createElement('tr');
	$tbl.append(tr);
	var arr = obj.split('::');
	
	//create enabled field
	var td = document.createElement('td');
	tr.appendChild(td);
	createEnabled(arr[4], tr, td, arr[2]);
	
	//create name field
	td = document.createElement('td');
	tr.appendChild(td);	
	createField(tr, td, arr[0], 'title', arr[4]);
	
	//create blank cell
	tr = document.createElement('tr');
	$tbl.append(tr);
	td = document.createElement('td');
	tr.appendChild(td);
	
	//start new table
	var tbl2 = document.createElement('table');
	td = document.createElement('td');
	tr.appendChild(td);
	td.appendChild(tbl2);
	tr = document.createElement('tr');
	tbl2.appendChild(tr);
	
	//create version field
	td = document.createElement('td');
	var str = isDev(arr[3]);
	td.innerText = 'v' + arr[1] + ' ' + str;
	if(str != ''){
		td.className = 'dev';
	}
	tr.appendChild(td);
	
	//create website link
	var a;
	if(arr[5] != ''){
		td = document.createElement('td');
		tr.appendChild(td);
		a = document.createElement('a');
		a.href = arr[5];
		a.target = '_blank';
		a.innerText = 'website';
		td.appendChild(a);
	}
	
	//create uninstall
	td = document.createElement('td');
	a = document.createElement('a');
	a.innerText = 'trash';
	a.href = '';
	tr.appendChild(td);
	td.appendChild(a);
	a.onclick =	function(){
		//alert(arr[4]);
		chrome.management.uninstall(arr[4], {showConfirmDialog: false}, function(){
			alert('unin');
/* 			chrome.runtime.sendMessage({greeting: "hello"}, function(response) {
				console.log(response.farewell);
			}); */
		});
		//location.reload;
	}
	
	//add id to table
	td = document.createElement('td');
	td.innerText = 'ID: ' + arr[4];
	tr.appendChild(td);
	
	//create some blank rows
	tr = document.createElement('tr');
	$tbl.append(tr);	
	tr = document.createElement('tr');
	$tbl.append(tr);	
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);	
	tr = document.createElement('tr');
	$tbl.append(tr);	
	tr = document.createElement('tr');
	$tbl.append(tr);	
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
	tr = document.createElement('tr');
	$tbl.append(tr);
}

function isDev(value){
	if(value == 'development'){
		return 'DEV';
	}else if(value != 'normal'){
		return value;
	}else{
		return '';
	}	
}

function createField(tr, td, value, cls, id){
	var label = document.createElement('label');
	td.appendChild(label);
	label.setAttribute('for', id);
	label.innerText = value;
	label.className = cls;
	td.appendChild(label);
}

function createEnabled(id, tr, td, value){
		var input = document.createElement('input');
		input.type = 'checkbox';
		input.id = id;
		input.name = id;
		if(value == 'true'){
			input.checked = true;
		}
		$(input).change(
			function(){
				var boo = false;
				if($(this).is(':checked')) boo = true;
				chrome.management.setEnabled(id, boo)
			}
		);
		td.appendChild(input);
}







