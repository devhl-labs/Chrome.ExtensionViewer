chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		localStorage['close'] = request.greeting;
		sendResponse({farewell: "bye"});
	}
);

if(!localStorage['close']) localStorage['close'] = 'false';
if(localStorage['close'] !== 'false'){
	setTimeout(
		function(){
			var num = 0;
			num = parseInt(localStorage['close']);
			chrome.tabs.create({url: "ev.html"});
			chrome.tabs.remove(num);
			localStorage['close'] = 'false';	
		}
	, 1000);
}


